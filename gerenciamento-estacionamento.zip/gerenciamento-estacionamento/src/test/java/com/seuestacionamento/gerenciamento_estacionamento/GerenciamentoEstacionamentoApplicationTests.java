package com.seuestacionamento.gerenciamento_estacionamento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GerenciamentoEstacionamentoApplicationTests {

	@Test
	void contextLoads() {
	}

}
